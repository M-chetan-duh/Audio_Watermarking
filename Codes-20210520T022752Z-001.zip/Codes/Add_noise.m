[sample,fs]=audioread('C:\Users\CHETAN\Desktop\Watermarking audio_code\lsb_modified\NN_lsb_mod.wav');
y=awgn(sample,10,'measured');
audiowrite('C:\Users\CHETAN\Desktop\Watermarking audio_code\lsb_modified\NN_lsb_mod_noise.wav', y, fs)
