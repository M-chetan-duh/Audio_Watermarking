clc;
clear all;
[input_noisy, fs]=audioread('BK.wav');
input_desired=audioread('BK_lsb_mod.wav');
N=length(input_desired); %both signal have same length
f1=fs/N*(-((N/2)-1):N/2);
fft_desired=fftshift((abs(fft(input_desired,N))).^2);
clean_power=1/N*sum(fft_desired);
%Power of noisy_speech
fft_noisy=fftshift((abs(fft(input_noisy,N))).^2);
noisy_power=1/N*sum(fft_noisy);
noise_power_in = noisy_power-clean_power;
noise_power_DB =abs(10*log10(noisy_power));
SNR_in=clean_power/noise_power_in;
SNR_in_dB=10*log10(SNR_in);

disp(abs(SNR_in_dB));