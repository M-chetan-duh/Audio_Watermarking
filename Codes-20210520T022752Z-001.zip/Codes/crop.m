[y, fs] = audioread('C:\Users\CHETAN\Desktop\Capstone_Project\audiosamples\KS.wav');
samples=[1,length(y)-(5*fs)];
[y1,fs] = audioread('C:\Users\CHETAN\Desktop\Capstone_Project\audiosamples\KS.wav',samples);
audiowrite('C:\Users\CHETAN\Desktop\Capstone_Project\audiosamples\KS_cut.wav',y1,fs);