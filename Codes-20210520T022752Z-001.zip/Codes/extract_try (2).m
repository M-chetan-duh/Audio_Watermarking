%% extract watermark from the audio file

clc
clear
close all 
%% load data
wm_sz     = 64800;                        % watermark size-change if using image of different size
px_sz     = wm_sz/8;                      % number of pixels
im_sz     = sqrt(px_sz);                  % image size
host_new  = audioread ('BK_lsb_mod.wav'); % watermarked host signal
host_new  = uint8(255*(host_new + 0.5));  % double [-0.5 +0.5] to 'uint8' [0 255]

%% prepare host
host_bin  = dec2bin(host_new, 8);         % binary host [n 8]


%% extract watermark
val=2;                                     %use the ratio obtained during insertion
wm_bin_str = host_bin(val:val:wm_sz*val, 8);
wm_bin    = reshape(wm_bin_str, px_sz , 8);
wm_str    = zeros(px_sz, 1, 'uint8');
for i     = 1:px_sz                        % extract water mark from the first plane of host               
wm_str(i, :) = bin2dec(wm_bin(i, :));      % Least Significant Bit (LSB)
end
wm        = reshape(wm_str, im_sz , im_sz);

%% show image
wm=imresize(wm,[500 500]);
imshow(wm)
imwrite(wm,'Recovered_watermark_noise_BK.png')