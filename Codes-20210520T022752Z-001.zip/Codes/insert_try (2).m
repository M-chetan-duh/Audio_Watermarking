%% Insert watermark into an audio file
 
          

clc;
clear;
close all ;
%% load data
[host, f] = audioread ('BK.wav');   % host signal
x = host(:,1);
y = host(:,2);
x      = uint8(255*(x + 0.5));      % double [-0.5 +0.5] to 'uint8' [0 255]

% Can work with any grayscale image-
% % img=imread('cameraman.png');
% % img2=rgb2gray(img);
% img2 = imread('LennaGray.png')
% imshow(rgb2gray(img2),[0 80]);

img2=imread('airplane.png');
wm        =imresize(img2,[90 90]);
imshow(wm)

%% watermark

[r, c]    = size(wm);                 % watermark size
wm_l      = length(wm(:))*8;          % watermark length

%% watermarking
if length(x) < (length(wm(:))*8)
    disp('Image pixels not enough')
else

val = floor(length(host)/wm_l);         %find positions to embed watermark
disp(val)
%% prepare host
x_bin  = dec2bin(x, 8); 
y_bin = dec2bin(x,8);
% binary host [n 8]
%% prepare watermark   
wm_bin    = dec2bin(wm(:), 8);        % binary watermark [n 8]
wm_str    = zeros(wm_l, 1);           % 1-D watermark [(n*8) 1]
for j = 1:8                           % convert [n 8] watermark to [(n*8) 1] watermark
for i = 1:length(wm(:))
ind   = (j-1)*length(wm(:)) + i;
wm_str(ind, 1) = str2double(wm_bin(i, j));
end
end
%% insert watermark into the host
for i     = val:val:wm_l*val                % insert water mark into the first plane of host               
x_bin(i, 8) = dec2bin(wm_str(i/val)); % Least Significant Bit (LSB)
end 
% for i=3:3:wm_l*3
% y_bin(i,8) = dec2bin(wm_str(i/3));
% end
%% watermarked host
x_new  = bin2dec(x_bin);   % watermarked host
x_new  = (double(x_new)/255 - 0.5);   % 'uint8' [0 255] to double [-0.5 +0.5]
% y_new = bin2dec(y_bin);
% y_new = (double(y_new)/255 - 0.5);
JS_new = [x_new y];
%% save the watermarked host
audiowrite('BK_lsb_mod.wav', JS_new, f)     % save watermarked host audio
end


